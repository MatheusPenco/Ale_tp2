package br.edu.fatecpg.filmes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmesApplicationTests {

	@Test
	void contextLoads() {
	}

}
